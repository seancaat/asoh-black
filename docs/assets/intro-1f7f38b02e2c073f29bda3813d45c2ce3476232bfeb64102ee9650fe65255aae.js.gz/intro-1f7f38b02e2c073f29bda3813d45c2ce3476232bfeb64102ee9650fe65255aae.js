var intro=document.querySelector(".intro"),enter=document.querySelector("a.enter");enter.onclick=function(){intro.classList.toggle("hidden")};
//# sourceMappingURL=/assets/source-maps/intro.js.map
//# sourceURL=_assets/js/intro.js
