function toggleMenu(){(menu=document.querySelector(".menu")).classList.toggle("hidden"),document.querySelector(".menu-button.close").classList.toggle("hidden"),document.querySelector(".menu-button.open").classList.toggle("hidden")}var menu;window.addEventListener("DOMContentLoaded",function(){document.querySelector(".menu-controls").addEventListener("click",toggleMenu,{passive:!0})});
//# sourceMappingURL=/assets/source-maps/menu.js.map
//# sourceURL=_assets/js/menu.js
